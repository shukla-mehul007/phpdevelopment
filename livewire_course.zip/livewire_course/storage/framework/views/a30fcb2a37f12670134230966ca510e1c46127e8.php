<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Livewire Coursers</title>

    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('show-users', [])->html();
} elseif ($_instance->childHasBeenRendered('H2yPBY3')) {
    $componentId = $_instance->getRenderedChildComponentId('H2yPBY3');
    $componentTag = $_instance->getRenderedChildComponentTagName('H2yPBY3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('H2yPBY3');
} else {
    $response = \Livewire\Livewire::mount('show-users', []);
    $html = $response->html();
    $_instance->logRenderedChild('H2yPBY3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html><?php /**PATH D:\xampp\htdocs\livewire_course\resources\views/index.blade.php ENDPATH**/ ?>