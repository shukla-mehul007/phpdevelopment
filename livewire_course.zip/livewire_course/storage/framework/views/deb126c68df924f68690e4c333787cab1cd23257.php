<div>
    <h3><?php echo e($title); ?></h3>
    <p>
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
    </p>

    <table width="500" cellpadding="2" cellspacing="5">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if($userlist != ""): ?>
                <?php $__currentLoopData = $userlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($userDetail->id); ?></td>
                        <td><?php echo e($userDetail->name); ?></td>
                        <td><?php echo e($userDetail->email); ?></td>
                        <td>
                            <a href="#;" wire:click="editUser(<?php echo e($userDetail->id); ?>)">Edit</a>
                            <a href="#;" wire:click="removeUser(<?php echo e($userDetail->id); ?>)">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>


    <?php if($this->userid != ""): ?>
    <form id="frmuser" name="frmuser" wire:submit.prevent="updateUser" method="POST">
    <?php else: ?>
    <form id="frmuser" name="frmuser" wire:submit.prevent="saveUser" method="POST">
    <?php endif; ?>
        
        
        <p><input type="text" wire:model="name" placeholder="Enter Name" /></p>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <p><input type="text" wire:model="email" placeholder="Enter Email" /></p>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <p><input type="password" wire:model="password" placeholder="Enter Password" /></p>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="hidden" wire:model="userid" />
        <p>
            <input type="submit" id="btnsubmit" name="btnsubmit" value="Submit" />
        </p>
    </form>
</div>
<?php /**PATH D:\xampp\htdocs\livewire_course\resources\views/livewire/show-users.blade.php ENDPATH**/ ?>