<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Livewire Coursers</title>

    @livewireStyles
</head>
<body>

    <livewire:show-users />

    @livewireScripts
</body>
</html>