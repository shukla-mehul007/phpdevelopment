<div>
    <h3>{{ $title }}</h3>
    <p>
        @if(session()->has('success'))
            <div class="alert alert-success" role="alert">
                {{ session()->get('success') }}
            </div>
        @endif
    </p>

    <table width="500" cellpadding="2" cellspacing="5">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @if($userlist != "")
                @foreach($userlist as $userDetail)
                    <tr>
                        <td>{{ $userDetail->id }}</td>
                        <td>{{ $userDetail->name }}</td>
                        <td>{{ $userDetail->email }}</td>
                        <td>
                            <a href="#;" wire:click="editUser({{ $userDetail->id }})">Edit</a>
                            <a href="#;" wire:click="removeUser({{ $userDetail->id }})">Delete</a>
                        </td>
                    </tr>
                @endforeach
            @endif
        </tbody>
    </table>


    @if($this->userid != "")
    <form id="frmuser" name="frmuser" wire:submit.prevent="updateUser" method="POST">
    @else
    <form id="frmuser" name="frmuser" wire:submit.prevent="saveUser" method="POST">
    @endif
        
        
        <p><input type="text" wire:model="name" placeholder="Enter Name" /></p>
        @error('name')
            <span class="text-danger">{{ $message }}</span>
        @enderror
        <p><input type="text" wire:model="email" placeholder="Enter Email" /></p>
        @error('email')
            <span class="text-danger">{{ $message }}</span>
        @enderror
        <p><input type="password" wire:model="password" placeholder="Enter Password" /></p>
        @error('password')
            <span class="text-danger">{{ $message }}</span>
        @enderror
        <input type="hidden" wire:model="userid" />
        <p>
            <input type="submit" id="btnsubmit" name="btnsubmit" value="Submit" />
        </p>
    </form>
</div>
