<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\User;
use Hash;

class ShowUsers extends Component
{
    public $userid;
    public $name;
    public $email;
    public $password;
    public $userlist;

    protected $rules = [
        'name' => 'required',
        'email' => 'required|unique:users',
        'password'=>'required',
    ];

    protected $messages = [
        'name.required'=>"Name is required",
        'email.required'=>"Email is required",
        'email.unique'=>"Email should be unique",
        'password.required'=>"Password is required"
    ];

    public function render()
    {
        $title = 'Users Module';
        $this->userlist = User::get();
        return view('livewire.show-users',['title'=>$title]);
    }

    public function mount(){
        $this->userlist = User::get();
    }

    public function saveUser()
    {
        $this->validate();
        $userCreate = User::create([
            "name"=>$this->name,
            "email"=>$this->email,
            "password"=>Hash::make($this->password)
        ]);
        session()->flash('success','User created successfully!!');
        
        $this->resetFields();
    }

    public function editUser($id)
    {
        $this->resetFields();
        $this->userid = $id;
        $userDetail = User::find($id);
        $this->name = $userDetail->name;
        $this->email = $userDetail->email;
    }

    public function updateUser()
    {
        $userDetail = User::find($this->userid);
        $userDetail->name = $this->name;
        $userDetail->email = $this->email;
        if($this->password != "")
        {
           $userDetail->password =  Hash::make($this->password);
        }
        $userDetail->save();
        session()->flash('success','User updated successfully!!');
        $this->resetFields();
    }

    public function removeUser($id){
        $this->userid = $id;
        $userDetail = User::find($this->userid);
        $userDetail->delete();
        session()->flash('success','User removed successfully!!');
        $this->resetFields();
    }

    public function resetFields(){
        $this->name = '';
        $this->email = '';
        $this->password = '';
        $this->id = '';
    }
}