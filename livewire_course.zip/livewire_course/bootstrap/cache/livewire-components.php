<?php return array (
  'show-users' => 'App\\Http\\Livewire\\ShowUsers',
);