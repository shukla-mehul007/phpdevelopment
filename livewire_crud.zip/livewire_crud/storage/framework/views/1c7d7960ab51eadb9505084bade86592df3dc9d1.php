<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Livewire Crud</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="/">Livewire CRUD Blog</a>
        </div>
    </nav>
    <div class="container">
        <div class="row justify-content-center mt-3">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('post')->html();
} elseif ($_instance->childHasBeenRendered('Xg9mQjT')) {
    $componentId = $_instance->getRenderedChildComponentId('Xg9mQjT');
    $componentTag = $_instance->getRenderedChildComponentTagName('Xg9mQjT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Xg9mQjT');
} else {
    $response = \Livewire\Livewire::mount('post');
    $html = $response->html();
    $_instance->logRenderedChild('Xg9mQjT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
 
    <?php echo \Livewire\Livewire::scripts(); ?>

  </body>
</html><?php /**PATH D:\xampp\htdocs\livewire_crud\resources\views/home.blade.php ENDPATH**/ ?>