<html>
    <body>
        <h3>Users to Contact :: User has one contact</h3>
        <table width="300" cellpadding="2" cellspacing="5">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Mobile</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($detail->id); ?></td>
                        <td><?php echo e($detail->name); ?></td>
                        <td><?php echo e($detail->mobiles->mobile_no); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </body>
</html><?php /**PATH D:\xampp\htdocs\laravel10\onetooneRelation\resources\views/users_to_contact.blade.php ENDPATH**/ ?>