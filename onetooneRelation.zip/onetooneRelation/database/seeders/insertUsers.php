<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use Hash;

class insertUsers extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = User::create(['name'=>'Mehul Shukla',
                'password'=>Hash::make('123456'),
            ]);
            $users = User::create(['name'=>'Pooja Shukla',
                'password'=>Hash::make('123456'),
            ]);
            $users = User::create(['name'=>'Aarav Shukla',
                'password'=>Hash::make('123456'),
            ]);
            $users = User::create(['name'=>'Aarti Shukla',
                'password'=>Hash::make('123456'),
            ]);
        
    }
}
