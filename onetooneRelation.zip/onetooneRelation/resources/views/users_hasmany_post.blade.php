<html>
    <body>
        <h3>Contact to Users :: Contact belongs Users</h3>
        <table width="500" cellpadding="2" cellspacing="5">
            <thead>
                <tr>
                    <th width="100">ID</th>
                    <th width="100">Name</th>
                    <th width="100">Mobile</th>
                    <th width="200">Posts</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($users as $detail)
                    <tr>
                        <td>{{ $detail->id }}</td>
                        <td>{{ $detail->name }}</td>
                        <td>{{ $detail->mobiles->mobile_no }}</td>
                        <td>
                            <table>
                                @foreach ($detail->userposts as $post_detail)
                                    <tr>
                                        <td>{{  $post_detail->post_title }}</td>
                                    </tr>
                                @endforeach
                            </table>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </body>
</html>