<html>
    <body>
        <h3>Users to Contact :: User has one contact</h3>
        <table width="300" cellpadding="2" cellspacing="5">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Mobile</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($users as $detail)
                    <tr>
                        <td>{{ $detail->id }}</td>
                        <td>{{ $detail->name }}</td>
                        <td>{{ $detail->mobiles->mobile_no }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </body>
</html>