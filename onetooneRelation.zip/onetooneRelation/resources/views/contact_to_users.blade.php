<html>
    <body>
        <h3>Contact to Users :: Contact belongs Users</h3>
        <table width="300" cellpadding="2" cellspacing="5">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>UserId</th>
                    <th>Mobile</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($contacts as $detail)
                    <tr>
                        <td>{{ $detail->id }}</td>
                        <td>{{ $detail->users->name }}</td>
                        <td>{{ $detail->users->id }}</td>
                        <td>{{ $detail->mobile_no }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </body>
</html>