<html>
    <body>
        <h3>Contact to Users :: Contact belongs Users</h3>
        <table width="500" cellpadding="2" cellspacing="5">
            <thead>
                <tr>
                    <th width="100">ID</th>
                    <th width="100">Post Title</th>
                    <th width="100">User Id</th>
                    <th width="100">User Name</th>
                    <th width="100">Contact</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($posts as $detail)
                    <tr>
                        <td>{{ $detail->id }}</td>
                        <td>{{ $detail->post_title }}</td>
                        <td>{{ $detail->users->id }}</td>
                        <td>{{ $detail->users->name }}</td>
                        <td>{{ $detail->users->mobiles->mobile_no }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </body>
</html>