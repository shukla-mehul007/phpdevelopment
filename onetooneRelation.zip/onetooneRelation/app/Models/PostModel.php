<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;

class PostModel extends Model
{
    use HasFactory;
    protected $fillable = ['post_title','post_desc','user_id'];
    protected $table = "posts";

    //every post is belongs to users
    public function users(){
        return $this->belongsTo(User::class,'user_id');
    }

    //contact is also belongs to user.
    // post is also belongs to user
    // so contact is also belongs to post of user.
    // id is primary key for the user table.
    public function usermobiles()
    {
        return $this->belongsTo(Contact::class,"id");
    }
}
