<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Contact;
use App\Models\PostModel;

class TestController extends Controller
{
    public function getUsers(){
        $users = User::with('mobiles')->get();
        return view('users_to_contact',['users'=>$users]);
    }

    public function getContacts(){
        $contacts = Contact::with('users')->get();
        return view('contact_to_users',['contacts'=>$contacts]);
    }

    public function userHasManyPost(){
        $users = User::with('userposts')->with('mobiles')->get();
        return view('users_hasmany_post',['users'=>$users]);
    }

    public function postBelongsToUser(){
        $posts = PostModel::with('users')->with('usermobiles')->get();
        return view('post_belongs_to_user',['posts'=>$posts]);
    }
    
}
