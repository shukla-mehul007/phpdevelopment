<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Author;
use App\Models\Post;

class TestController extends Controller
{
    public function authorHasManyPost(){
        $authors = Author::with('post')->get();
        return view('authors',['authors'=>$authors]);
    }

    public function postBelongstoAuthor(){
        $posts = Post::with('author')->get();
        return view('posts',['posts'=>$posts]);
    }
}
