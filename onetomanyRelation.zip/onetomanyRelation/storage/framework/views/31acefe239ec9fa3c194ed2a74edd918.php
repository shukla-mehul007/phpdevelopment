<html>
    <body>
        <h3>Author Has Many Post</h3>
        <table width='500' border='1' cellpadding='5' cellspacing='2'> 
            <thead>
                <tr>
                    <td width='100'>Author Name</td>
                    <td width='100'>Author Mobile</td>
                    <td width='300'>Author Post</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $authorDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($authorDetail->author_name); ?></td>
                        <td><?php echo e($authorDetail->author_mobile); ?></td>
                        <td valign="top">
                            <table border='1'>
                                <?php $__currentLoopData = $authorDetail->post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr><td><?php echo e($postDetail->post_title); ?></td>
                                    <td><?php echo e($postDetail->cat); ?></td></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </body>
</html><?php /**PATH D:\xampp\htdocs\laravel10\onetomanyRelation\resources\views/authors.blade.php ENDPATH**/ ?>