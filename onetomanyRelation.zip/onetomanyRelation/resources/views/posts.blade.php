<html>
    <body>
        <h3>Post Belongs to Author</h3>
        <table width='500' border='1' cellpadding='5' cellspacing='2'> 
            <thead>
                <tr>
                    <td width='200'>Title</td>
                    <td width='100'>Category</td>
                    <td width='100'>Author Name</td>
                    <td width='100'>Author Contact</td>
                </tr>
            </thead>
            <tbody>
                @foreach($posts as $postDetail)
                    <tr>
                        <td>{{  $postDetail->post_title }}</td>
                        <td>{{  $postDetail->cat }}</td>
                        <td>{{  $postDetail->author->author_name }}</td>
                        <td>{{  $postDetail->author->author_mobile }}</td>
                        
                    </tr>
                @endforeach
            </tbody>
        </table>
    </body>
</html>