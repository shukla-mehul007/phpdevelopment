<html>
    <body>
        <h3>Author Has Many Post</h3>
        <table width='500' border='1' cellpadding='5' cellspacing='2'> 
            <thead>
                <tr>
                    <td width='100'>Author Name</td>
                    <td width='100'>Author Mobile</td>
                    <td width='300'>Author Post</td>
                </tr>
            </thead>
            <tbody>
                @foreach($authors as $authorDetail)
                    <tr>
                        <td>{{  $authorDetail->author_name }}</td>
                        <td>{{  $authorDetail->author_mobile }}</td>
                        <td valign="top">
                            <table border='1'>
                                @foreach($authorDetail->post as $postDetail)
                                    <tr><td>{{ $postDetail->post_title }}</td>
                                    <td>{{ $postDetail->cat }}</td></tr>
                                @endforeach
                            </table>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </body>
</html>