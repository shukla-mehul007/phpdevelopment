<html>
    <body>
        <table border="1" cellpadding="2" cellspacing="5" width="800">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Song Title</th>
                    <th>Singer Name</th>
                </tr>
            </thead>
            <tbody>
                @foreach($songs as $song)
                    <tr>
                        <td width="100">{{  $song->id }}</td>
                        <td width="300">{{  $song->title }}</td>
                        <td width="300">
                            <table>
                                @foreach($song->singer as $singerDetail)
                                    <tr>
                                        <td width="50">{{  $singerDetail->id }}</td>
                                        <td width="100">{{  $singerDetail->fullname }}</td>
                                    </tr>
                                @endforeach
                            </table>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </body>
</html>