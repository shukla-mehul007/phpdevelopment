<html>
    <body>
        <table border="1" cellpadding="2" cellspacing="5" width="800">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Singer Name</th>
                    <th>Song Title</th>
                </tr>
            </thead>
            <tbody>
                @foreach($singers as $singer)
                    <tr>
                        <td width="100">{{  $singer->id }}</td>
                        <td width="300">{{  $singer->fullname }}</td>
                        <td width="300">
                            <table>
                                @foreach($singer->song as $songDetail)
                                    <tr>
                                        <td width="50">{{  $songDetail->id }}</td>
                                        <td width="100">{{  $songDetail->title }}</td>
                                    </tr>
                                @endforeach
                            </table>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </body>
</html>