<html>
    <body>
        <table border="1" cellpadding="2" cellspacing="5" width="800">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Singer Name</th>
                    <th>Song Title</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $singers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td width="100"><?php echo e($singer->id); ?></td>
                        <td width="300"><?php echo e($singer->fullname); ?></td>
                        <td width="300">
                            <table>
                                <?php $__currentLoopData = $singer->song; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $songDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td width="50"><?php echo e($songDetail->id); ?></td>
                                        <td width="100"><?php echo e($songDetail->title); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </body>
</html><?php /**PATH D:\xampp\htdocs\laravel10\manytomanyRelation\resources\views/singerstosong.blade.php ENDPATH**/ ?>