<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Singer;
use App\Models\Song;

class TestController extends Controller
{
    public function SingertoSong()
    {
        $singers = Singer::with('song')->get();
        return view('singerstosong',['singers'=>$singers]);
    }

    public function SongtoSinger()
    {
        $songs = Song::with('singer')->get();
        return view('songtosingers',['songs'=>$songs]);
    }
}
