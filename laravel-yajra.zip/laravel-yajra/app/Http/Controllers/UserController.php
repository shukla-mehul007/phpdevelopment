<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use DataTables;

class UserController extends Controller
{
    //reference side.
    //https://techvblogs.com/blog/laravel-server-side-datatables-example
    public function index(Request $request)
    {
        if ($request->ajax()) 
        {
            $data = User::select('id','name','email','created_at')->orderBy('id','DESC')->get();
            return Datatables::of($data)->addIndexColumn()
                ->addColumn('action', function($row){
                    $view_url = url("viewusers/".$row->id);
                    $delete_url = url("deleteusers");
                    $btn = '<a href="'.$view_url.'" class="btn btn-primary btn-sm">View</a>&nbsp;&nbsp;<a href="javascript::void(0)" class="btn btn-danger btn-sm userremove" data-id="'.$row->id.'">Delete</a>';

                    return $btn;
                })
                ->setRowClass(function ($user) {
                    return $user->id % 2 == 0 ? 'alert-default' : 'alert-danger';
                })
                ->setRowId(function ($user) {
                    return $user->id;
                })
                ///->rawColumns(['action'])
                ->make(true);
        }

        return view('users');
    }

    public function userDetail($id)
    {
        $user = User::find($id);
        dd($user);
    }

    public function removeUser(Request $request)
    {
        $input = $request->all();
        $userDetail = User::find($input['userid']);
        $userDetail->delete();
        die();
    }
}
