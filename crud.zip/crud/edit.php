<?php include("connection.php"); 

if(isset($_POST['btnsubmit']))
{
	$id = $_POST['id'];
	$fname = $_POST['firstname'];
	$lname = $_POST['lastname'];
	$age = $_POST['stud_age'];
	
	$update_query = "Update student set fname = '".$fname."',lname='".$lname."',age='".$age."' WHERE id='".$id."'";
	$update_result = mysqli_query($conn,$update_query);
	$_SESSION["message"] = "Updated successfully";
	header("location:index.php");
}

if(isset($_GET['id']))
{
	$sel_query = "select * from student where id='".$_GET['id']."'";
	$sel_result = mysqli_query($conn,$sel_query);
	$sel_row = mysqli_fetch_assoc($sel_result);
}
?>
<html>
<body>
<form id="frm1" name="frm1" method="post" action="">
	<p><input type="text" id="firstname" name="firstname" value="<?php echo $sel_row['fname']; ?>" placeholder="Enter first name" /></p>
	<p><input type="text" id="lastname" name="lastname" value="<?php echo $sel_row['lname']; ?>" placeholder="Enter Last name" /></p>
	<p><input type="text" id="stud_age" name="stud_age" value="<?php echo $sel_row['age']; ?>" placeholder="Enter age" /></p>
	<p>
	<input type="hidden" id="id" name="id" value="<?php echo $sel_row['id']; ?>" />
	<input type="submit" id="btnsubmit" name="btnsubmit" value="Submit"  />
	</p>
</form>
</body>
</html>