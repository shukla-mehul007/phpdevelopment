<?php include("connection.php"); 

if(isset($_POST['btnsubmit']))
{
	$fname = $_POST['firstname'];
	$lname = $_POST['lastname'];
	$age = $_POST['stud_age'];
	
	$insert_query = "insert into student set fname = '".$fname."',lname='".$lname."',age='".$age."'";
	$insert_result = mysqli_query($conn,$insert_query);
	$_SESSION["message"] = "Inserted successfully";
	header("location:index.php");
}
?>
<html>
<body>
<form id="frm1" name="frm1" method="post" action="">
	<p><input type="text" id="firstname" name="firstname" value="" placeholder="Enter first name" /></p>
	<p><input type="text" id="lastname" name="lastname" value="" placeholder="Enter Last name" /></p>
	<p><input type="text" id="stud_age" name="stud_age" value="" placeholder="Enter age" /></p>
	<p><input type="submit" id="btnsubmit" name="btnsubmit" value="Submit"  /></p>
</form>
</body>
</html>