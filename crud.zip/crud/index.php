<?php include("connection.php"); 

if(isset($_GET['del_id']))
{
	$del_query = "Delete from student where id='".$_GET['del_id']."'";
	$del_result = mysqli_query($conn,$del_query);
	$_SESSION["message"] = "Deleted successfully";
	header("location:index.php");
}
?>
<html>
<body>
<p><a href="add.php">Add Student</a></p>
<?php
	if(isset($_SESSION["message"]) && $_SESSION["message"] != "")
	{
		?>
		<span style="color:green"><?php echo $_SESSION["message"]; ?></span>
		<?php
		$_SESSION["message"] = "";
	}
?>
<table border="1">
	
	<thead>
		<tr>
			<th>Id</th>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Age</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
	<?php
		$sel_qry = "select * from student";
		$sel_res = mysqli_query($conn,$sel_qry);
		while($sel_row = mysqli_fetch_assoc($sel_res))
		{
			?>
			<tr>
				<td><?php echo $sel_row['id']; ?></td>
				<td><?php echo $sel_row['fname']; ?></td>
				<td><?php echo $sel_row['lname']; ?></td>
				<td><?php echo $sel_row['age']; ?></td>
				<td>
					<a href="edit.php?id=<?php echo $sel_row['id']; ?>">Edit</a>
					<a href="index.php?del_id=<?php echo $sel_row['id']; ?>" onclick="return confirm('Are you sure to delete it?')">Delete</a>
				</td>
			</tr>
			<?php
		
		}
	?>
	</tbody>
</table>
</body>
</html>