<?php @ob_start();
@session_start(); 
$conn = mysqli_connect("localhost","root","","test");
?>