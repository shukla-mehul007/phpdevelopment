<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;


class TestController extends Controller
{
    
    public function showdate(){
        $mydate ="2024-04-25";
        $newdate = changeDateFormat($mydate);
        echo $newdate;
    }
}
