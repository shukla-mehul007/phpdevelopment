<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Student;
use Hash;
use Str;
use Faker\Factory as Faker;

class studentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        /*Student::create([
            'name'=>'Mehul',
            'email'=>'mehul@gmail.com',
            'password'=>Hash::make('123456')
        ]);

        Student::create([
            'name'=>'Pooja',
            'email'=>'pooja@gmail.com',
            'password'=>Hash::make('123456')
        ]);

        Student::create([
            'name'=>'Aarav',
            'email'=>'aarav@gmail.com',
            'password'=>Hash::make('123456')
        ]);

        Student::create([
            'name'=>Str::random(10),
            'email'=>Str::random(10).'@gmail.com',
            'password'=>Hash::make(Str::random(10))
        ]);*/

        $facker = Faker::create();
        for($i=1;$i<=10;$i++)
        {
            Student::create([
                'name'=>$facker->name(),
                'email'=>$facker->email(),
                'password'=>Hash::make($facker->password())
            ]);
        }
    }
}
