<html>
<body>
	<p>Hello {{ $name }},<br/>{{ $msg }}</p>
</body>
</html>