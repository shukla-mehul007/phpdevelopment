<html>
<body>
	<p>Hello <?php echo e($name); ?>,<br/><?php echo e($msg); ?></p>
</body>
</html><?php /**PATH F:\laragon\www\schdulingDemo\resources\views/mail.blade.php ENDPATH**/ ?>