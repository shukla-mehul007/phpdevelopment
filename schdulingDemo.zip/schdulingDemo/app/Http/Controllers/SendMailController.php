<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;

class SendMailController extends Controller
{
    
    public function SendingEmail()
    {
        try 
        {
            $data = [
                'name' => "Mehul Shukla",
                'msg' => "This is testing email. Please ignore it."
            ];

            Mail::send('mail', $data, function($message) use($data) {
                $message->to('shuklamehul007@gmail.com', 'Tutorials Point')->subject('Laravel Basic Testing Mail');
                $message->from('developer.shuklamehul007@gmail.com','Pooja Shukla');
            });

            echo "Mail sent successfully";
        } 
        catch (\Exception $e) {
            \Log::error("Error in TestCron command: " . $e->getMessage());
            echo "Mail sending failed: " . $e->getMessage();
        }
    }
}
