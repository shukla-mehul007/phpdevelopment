<?php return array (
  'addpost' => 'App\\Http\\Livewire\\Addpost',
  'listposts' => 'App\\Http\\Livewire\\Listposts',
  'post' => 'App\\Http\\Livewire\\Post',
);