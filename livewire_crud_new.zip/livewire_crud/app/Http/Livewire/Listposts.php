<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Post as Posts;

class Listposts extends Component
{

    public $posts;
    protected $listeners = ['refreshComponent' => 'getAllPosts'];
    public function render()
    {
        $this->posts = Posts::select('id', 'title', 'description')->get();
        return view('livewire.listposts');
    }

    // This is emit method, useful when adding the post after without refresh calling from the addPost.
    public function getAllPosts()
    {
        $this->posts = Posts::select('id', 'title', 'description')->get();
    }
}