<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Post as Posts;

class Addpost extends Component
{
    public $title,$description;

    public function render()
    {
        return view('livewire.addpost');
    }

    protected $rules = [
        'title' => 'required',
        'description' => 'required'
    ];

    public function resetFieldDetail()
    {
        $this->title = '';
        $this->description = '';
    }

    public function cancelPostDetail()
    {
        $this->resetFieldDetail();
    }

    public function storePostDetail(){
        
        $this->validate();

        try {
            Posts::create([
                'title' => $this->title,
                'description' => $this->description
            ]);
            session()->flash('success','Post Created Successfully!!');
            $this->resetFieldDetail();
            $this->emit('refreshComponent');
        } catch (\Exception $ex) {
            session()->flash('error','Something goes wrong!!');
        }
    }
}