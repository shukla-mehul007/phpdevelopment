<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post as Posts;

class DetailController extends Controller
{
    public function index()
    {
        return view('details_post');
    }
}
