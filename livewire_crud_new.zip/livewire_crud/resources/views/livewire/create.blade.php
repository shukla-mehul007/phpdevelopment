<div class="card">
    <div class="card-body">
        <form wire:submit.prevent="storePost()">
            <div class="form-group mb-3">
                <label for="title">Title:</label>
                <input type="text" class="form-control @error('title') is-invalid @enderror" id="title" placeholder="Enter Title" wire:model="title">
                @error('title')
                    <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>
            <div class="form-group mb-3">
                <label for="description">Description:</label>
                <textarea class="form-control @error('description') is-invalid @enderror" id="description" wire:model="description" placeholder="Enter Description"></textarea>
                @error('description')
                    <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>

            <div class="form-group mb-3">
                <label for="photos">Upload Photo:</label>
                <input type="file" class="form-control @error('photos') is-invalid @enderror" id="photos" wire:model="photos" placeholder="Enter Photo" />
                @error('photos')
                    <span class="text-danger">{{ $message }}</span>
                @enderror
                @if($photos != "")
                    <img src="{{ $photos->temporaryUrl() }}" height="100" width="100" />
                @endif
            </div>
            <div wire:loading wire:target="photos">Uploading...</div>
            <div class="d-grid gap-2">
                <button  class="btn btn-success btn-block">Save</button>
                <button wire:click.prevent="cancelPost()" class="btn btn-secondary btn-block">Cancel</button>
            </div>
        </form>
    </div>
</div>