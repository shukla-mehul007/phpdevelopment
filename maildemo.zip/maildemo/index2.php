<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer autoloader
require 'vendor/autoload.php';

// Create a new PHPMailer instance
$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->isSMTP();
    /*$mail->Host       = 'sandbox.smtp.mailtrap.io';  // Specify the SMTP server
    $mail->SMTPAuth   = true;                 // Enable SMTP authentication
    $mail->Username   = '835b1f69f3a9f3';                     //SMTP username
    $mail->Password   = '61edaaddda968f';   
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
    $mail->Port       = 2525;                  // TCP port to connect to
	*/
	
	$mail->Host       = 'smtp.gmail.com';  // Specify the SMTP server
    $mail->SMTPAuth   = true;                 // Enable SMTP authentication
    $mail->Username   = 'developer.shuklamehul007@gmail.com';                     //SMTP username
    $mail->Password   = 'natsggrdnkkxpbbs';   
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
    $mail->Port       = 587;                  // TCP port to connect to
	
    // Sender and recipient settings
    $mail->setFrom('developer.shuklamehul007@gmail.com', 'Mehul SHukla');
    $mail->addAddress('shuklamehul007@gmail.com', 'Pooja SHukla');

    // Content
    $mail->isHTML(true);  // Set email format to HTML
    $mail->Subject = 'Testing Email';
    $mail->Body    = 'Hello,<br/> This is testing email by the mehul shukla';

    // Attachments (if needed)
    // $mail->addAttachment('path/to/file.pdf');

    // Send the email
    $mail->send();
    echo 'Email has been sent successfully!';
} catch (Exception $e) {
    echo "Error sending email: {$mail->ErrorInfo}";
}
