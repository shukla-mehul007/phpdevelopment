<div>
    <style type="text/css">
    table select{
         padding: 5px;
         min-width: 200px;
    }
    </style>

    <table>
        <tr>
            <td>Country</td>
            <td>
                <select wire:model="country_id" wire:change="getCountryStates">
                    <option value="0">-- Select Country --</option>
                    @foreach($countries as $country)
                         <option value="{{ $country->id }}">{{ $country->name }}</option>
                    @endforeach
                </select>
            </td>
        </tr>
        <tr>
            <td>State</td>
            <td>
                <select wire:model="state_id" wire:change="getStateCities">
                    <option value="0">-- Select State --</option>
                    @if(!empty($states))
                         @foreach($states as $state)
                              <option value="{{ $state->id }}">{{ $state->name }}</option>
                         @endforeach
                    @endif
                </select>
            </td>
        </tr>
        <tr>
            <td>City</td>
            <td>
                <select wire:model="city_id">
                    <option value="0">-- Select City --</option>
                    @if(!empty($cities))
                        @foreach($cities as $city)
                             <option value="{{ $city->id }}">{{ $city->name }}</option>
                        @endforeach
                    @endif
                </select>
            </td>
        </tr>
    </table>

</div>
