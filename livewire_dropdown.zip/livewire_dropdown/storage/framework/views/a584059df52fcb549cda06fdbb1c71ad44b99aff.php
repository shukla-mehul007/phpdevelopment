<div>
    <style type="text/css">
    table select{
         padding: 5px;
         min-width: 200px;
    }
    </style>

    <table>
        <tr>
            <td>Country</td>
            <td>
                <select wire:model="country_id" wire:change="getCountryStates">
                    <option value="0">-- Select Country --</option>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>State</td>
            <td>
                <select wire:model="state_id" wire:change="getStateCities">
                    <option value="0">-- Select State --</option>
                    <?php if(!empty($states)): ?>
                         <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>City</td>
            <td>
                <select wire:model="city_id">
                    <option value="0">-- Select City --</option>
                    <?php if(!empty($cities)): ?>
                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </td>
        </tr>
    </table>

</div>
<?php /**PATH D:\xampp\htdocs\livewire_dropdown\resources\views/livewire/autopopulate-dropdown.blade.php ENDPATH**/ ?>