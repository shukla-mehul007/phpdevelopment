<html>
    <body>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                </tr>
            </thead>
            <tbody>
                @foreach($catlist as $detail)
                    <tr>
                        <td>{{  $detail->id }}</td>
                        <td>{{  $detail->cat_title }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </body>
</html>