<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Traits\ShowAllCategoriesTrait;


class TestController extends Controller
{
    use ShowAllCategoriesTrait;

    public function categorylist(){
        $catlist = $this->getAllList();
        return view("categorylist",['catlist'=>$catlist]);
    }
    

}
