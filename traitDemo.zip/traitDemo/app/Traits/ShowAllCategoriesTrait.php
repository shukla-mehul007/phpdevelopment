<?php 

namespace App\Traits;

use App\Models\Category;

trait ShowAllCategoriesTrait{

    public function getAllList(){
        $allcategories = Category::get();
        return $allcategories;
    }
}

?>