<?php

namespace App\Http\Controllers\Auth;
//use the facade here
use Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AdminLoginController extends Controller
 {
    public function _construct()
    {
        $this->middleware('guest:admin');
        //$this->middleware('guest:admin')->except('logout');
    }

    public function showLoginForm()
    {
        return view('auth.admin_login');
    }

    public function login(Request $request)
    {
        //---Validate the form data
        $this->validate($request, [
            'email'=>'required|email',
            'password'=>'required|min:6'
        ]);

        //---Attempt to log in
        //---If successful, then redirect to their intended location
        //---If unsuccessful, then redirect to form data
        if (Auth::guard('admin')->attempt(['email'=> $request->email,'password'=>$request->password], $request->remember))
        {
            //return redirect()->intended(route('admin.home'));
            return redirect()->route('admin.home');
        }

        return redirect()->back()->withInput($request->only('email', 'remember'))->withErrors(["email" => "Email or password is incorrect"]);

    }

    public function logout(Request $request)
    {
        Auth::guard('admin')->logout();
        return redirect('admin/login');
    }

}
