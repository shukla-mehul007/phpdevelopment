<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Imports\CustomerImport;
use Maatwebsite\Excel\Facades\Excel;
use Session;
use App\Models\Customer;

class CustomerController extends Controller
{
    //reference this code =>  https://www.fundaofwebit.com/post/how-to-import-excel-file-data-into-database-in-laravel

    public function customerList()
    {
        $customer_list = Customer::get();
        return view('customer_list',['customer_list'=>$customer_list]);
    }

    public function uploadFile()
    {
        return view("uploadfile");
    }

    public function insertData(Request $request)
    {
        Excel::import(new CustomerImport, $request->file('customer_upload'));
        Session::flash("message","Data inserted successfully");
        return redirect('customerList');
    }
}
