<html>
<body>
	<h2>Upload Excel file data save into database</h2>
	<form id="frmupload" name="frmupload" action="{{ url('insertData') }}" method="post" enctype="multipart/form-data">
		@csrf
		<p><input type="file" name="customer_upload" value="" /></p>
		<p><input type="submit" name="btnsubmit" value="Submit" /></p>
	</form>
</body>
</html>