<html>
<body>
	<h2>Customer List</h2>
	@if(Session::has('message'))
	<p>{{ Session('message') }}</p>
	@endif
	<table width="400" cellpadding="2" cellspacing="5" border="1">
		<thead>
		<tr>
			<th width="100">ID</th>
			<th width="100">Name</th>
			<th width="100">Email</th>
			<th width="100">Phone</th>
		</tr>
		</thead>
		<tbody>
			@if($customer_list != null)
			@foreach($customer_list as $detail)
			<tr>
				<td>{{ $detail->id }}</td>
				<td>{{ $detail->name }}</td>
				<td>{{ $detail->email }}</td>
				<td>{{ $detail->phone }}</td>
			</tr>
			@endforeach
			@endif
		</tbody>
	</table>
</body>
</html>