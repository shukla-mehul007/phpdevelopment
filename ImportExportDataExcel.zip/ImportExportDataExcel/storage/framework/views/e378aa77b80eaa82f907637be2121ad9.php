<html>
<body>
	<h2>Customer List</h2>
	<?php if(Session::has('message')): ?>
	<p><?php echo e(Session('message')); ?></p>
	<?php endif; ?>
	<table width="400" cellpadding="2" cellspacing="5" border="1">
		<thead>
		<tr>
			<th width="100">ID</th>
			<th width="100">Name</th>
			<th width="100">Email</th>
			<th width="100">Phone</th>
		</tr>
		</thead>
		<tbody>
			<?php if($customer_list != null): ?>
			<?php $__currentLoopData = $customer_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($detail->id); ?></td>
				<td><?php echo e($detail->name); ?></td>
				<td><?php echo e($detail->email); ?></td>
				<td><?php echo e($detail->phone); ?></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</tbody>
	</table>
</body>
</html><?php /**PATH D:\xampp\htdocs\laravel10\ImportExportDataExcel\resources\views/customer_list.blade.php ENDPATH**/ ?>